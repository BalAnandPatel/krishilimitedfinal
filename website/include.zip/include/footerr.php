<br><br>

<section class="content footer_logo">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="">
                    <div class="swiper mySwiper0">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide swiper-slide_" style="width:150px !important;height: 150px !important">
                                <a class="redirectconfirmation" href="http://cashlessindia.gov.in/" target="_blank"><img alt="cashlessindia" src="assets/images/minister/cashlessindia.png"></a>
                            </div>
                            <div class="swiper-slide swiper-slide_" style="width:150px !important;height: 150px !important;">
                                <a class="redirectconfirmation"  href="https://pgportal.gov.in/" target="_blank"><img alt="public" src="assets/images/minister/public.png"></a>
                            </div>

                            <div class="swiper-slide swiper-slide_" style="width:150px !important;height: 150px !important;">
                                <a class="redirectconfirmation"  href="https://igod.gov.in/" target="_blank"><img alt="webdirectory" src="assets/images/minister/webdirectory.png"></a>
                            </div>
                            <div class="swiper-slide swiper-slide_" style="width:150px !important;height: 150px !important;">
                                <a class="redirectconfirmation"  href="https://www.digitalindia.gov.in/" target="_blank"><img alt="degitalindia" src="assets/images/minister/degitalindia.png"></a>
                            </div>
                            <div class="swiper-slide swiper-slide_" style="width:150px !important;height: 150px !important;">
                                <a  class="redirectconfirmation" href="https://www.mygov.in/" target="_blank"><img alt="mygov" src="assets/images/minister/mygov.png"></a>
                            </div>
                            <div class="swiper-slide swiper-slide_" style="width:150px !important;height: 150px !important;">
                                <a class="redirectconfirmation"  href="https://www.makeinindia.com/home" target="_blank"><img alt="makeinindia" src="assets/images/minister/makeinindia.png"></a>
                            </div>
                            <div class="swiper-slide swiper-slide_" style="width:150px !important;height: 150px !important;">
                                <a class="redirectconfirmation"  href="https://data.gov.in/" target="_blank"><img alt="datagov" src="assets/images/minister/datagov.png"></a>
                            </div>
                            <div class="swiper-slide swiper-slide_" style="width:150px !important;height: 150px !important;">
                                <a class="redirectconfirmation"  href="https://www.india.gov.in/" target="_blank"><img alt="indiagov" src="assets/images/minister/indiagov.png"></a>
                            </div>

                        </div>
                        <div class="swiper-pagination"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>









<footer class="text-center text-lg-start bg-light text-muted" style="padding-bottom:0px;">
    <section class="content bg1a1a1a">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <ul class="footer_link ">
                        <li class="font_size"><a class="font_size" href="index.php">Home</a></li>
                        <li class="font_size"><a class="font_size" href="about.php">About</a></li>
                        <li class="font_size"><a class="font_size" href="service_agriculture.php">Services</a></li>
                        <li class="font_size"><a class="font_size" href="blog_details_agriculture.php">Blogs</a></li>
                        <li class="font_size"><a class="font_size" href="contactmin.php">Contact Us</a></li>

                        <li class="font_size"><a class="font_size" href="cancelreturn.php">Cancel Return</a></li>
                        <li class="font_size"><a class="font_size" href="shipping.php">Shipping</a></li>
                        <li class="font_size"><a class="font_size" href="privacy_policy.php">Privacy Policy</a></li>
                        <li class="font_size"><a class="font_size" href="terms.php">Terms & Conditions</a></li>
                        <li class="font_size"><a class="font_size" href="gallery.php">Photo Gallery</a></li>
                        <li class="font_size"><a class="font_size" href="news.php">E-News</a></li>
                        <li class="font_size"><a class="font_size" href="contactmin.php">Contact</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class="content bg252525">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                        <h4 class="department_content font_size">
                            Website Content Owned & Managed by Department of Agriculture & Farmers Welfare | MoA & FW | Government of India, India
                            <!--| Last Updated: <span id="spnLastupdate">--><!--</span>-->
                            <br />
                            Designed and Developed by <a href="https://www.glintel.com/">Glintel Technologies</a>
                            <br /> Last Updated On: 14 Apr 2023<br />
                            
                            Visitors: <span id="span_visitor"></span> 
                            
                        </h4>


                    
                </div>
            </div>
        </div>

    </section>

</footer>