<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Exam Details</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../common/plugins/fontawesome-free/css/all.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="../common/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../common/dist/css/adminlte.min.css">
  <link rel="stylesheet" href="../common/build/scss/pages/_login_and_register.scss">
</head>

<body class="hold-transition register-page">

  <form action="action/payment_entry_post.php" method="post">

    <input type="text" placeholder="user_id" name="user_id"><br><br>


    <input type="text" placeholder="amount" name="amount"><br><br>

    
    <input type="text" placeholder="transaction_id" name="transaction_id"><br><br>

    <input type="text" placeholder="request_id" name="request_id"><br><br>


    <input type="submit" name="submit" value="Submit"></submit>

  </form>

</body>
</html>
