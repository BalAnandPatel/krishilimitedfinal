<br><br>

<section class="content footer_logo">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="">
                    <div class="swiper mySwiper0">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide swiper-slide_" style="width:150px !important;height: 150px !important">
                                <a class="redirectconfirmation" href="http://cashlessindia.gov.in/" target="_blank"><img alt="cashlessindia" src="assets/images/minister/cashlessindia.png"></a>
                            </div>
                            <div class="swiper-slide swiper-slide_" style="width:150px !important;height: 150px !important;">
                                <a class="redirectconfirmation"  href="https://pgportal.gov.in/" target="_blank"><img alt="public" src="assets/images/minister/public.png"></a>
                            </div>

                            <div class="swiper-slide swiper-slide_" style="width:150px !important;height: 150px !important;">
                                <a class="redirectconfirmation"  href="https://igod.gov.in/" target="_blank"><img alt="webdirectory" src="assets/images/minister/webdirectory.png"></a>
                            </div>
                            <div class="swiper-slide swiper-slide_" style="width:150px !important;height: 150px !important;">
                                <a class="redirectconfirmation"  href="https://www.digitalindia.gov.in/" target="_blank"><img alt="degitalindia" src="assets/images/minister/degitalindia.png"></a>
                            </div>
                            <div class="swiper-slide swiper-slide_" style="width:150px !important;height: 150px !important;">
                                <a  class="redirectconfirmation" href="https://www.mygov.in/" target="_blank"><img alt="mygov" src="assets/images/minister/mygov.png"></a>
                            </div>
                            <div class="swiper-slide swiper-slide_" style="width:150px !important;height: 150px !important;">
                                <a class="redirectconfirmation"  href="https://www.makeinindia.com/home" target="_blank"><img alt="makeinindia" src="assets/images/minister/makeinindia.png"></a>
                            </div>
                            <div class="swiper-slide swiper-slide_" style="width:150px !important;height: 150px !important;">
                                <a class="redirectconfirmation"  href="https://data.gov.in/" target="_blank"><img alt="datagov" src="assets/images/minister/datagov.png"></a>
                            </div>
                            <div class="swiper-slide swiper-slide_" style="width:150px !important;height: 150px !important;">
                                <a class="redirectconfirmation"  href="https://www.india.gov.in/" target="_blank"><img alt="indiagov" src="assets/images/minister/indiagov.png"></a>
                            </div>

                        </div>
                        <div class="swiper-pagination"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>









<footer class="text-center text-lg-start bg-light text-muted" style="padding-bottom:0px;">
    <section class="content bg1a1a1a">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <ul class="footer_link ">
                        <li class="font_size"><a class="font_size" href="index.php">Home</a></li>
                        <li class="font_size"><a class="font_size" href="about.php">About</a></li>
                        <li class="font_size"><a class="font_size" href="service_agriculture.php">Services</a></li>
                        <li class="font_size"><a class="font_size" href="blog_details_agriculture.php">Blogs</a></li>
                        <li class="font_size"><a class="font_size" href="contactmin.php">Contact Us</a></li>

                        <li class="font_size"><a class="font_size" href="cancelreturn.php">Cancel Return</a></li>
                        <li class="font_size"><a class="font_size" href="shipping.php">Shipping</a></li>
                        <li class="font_size"><a class="font_size" href="privacy_policy.php">Privacy Policy</a></li>
                        <li class="font_size"><a class="font_size" href="terms.php">Terms & Conditions</a></li>
                        <li class="font_size"><a class="font_size" href="gallery.php">Photo Gallery</a></li>
                        <li class="font_size"><a class="font_size" href="news.php">E-News</a></li>
                        <li class="font_size"><a class="font_size" href="contactmin.php">Contact</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class="content bg252525">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                        <h4 class="department_content font_size">
                            Website Content Given & Managed by Shyamavsvss Krishi Limited 
                            <!--| Last Updated: <span id="spnLastupdate">--><!--</span>-->
                            <br />
                            Designed and Developed by <a href="https://www.glintel.com/">Glintel Technologies</a>
                            Visitors: <span id="span_visitor"></span> 
                            
                        </h4>


                    
                </div>
            </div>
        </div>

    </section>

</footer>
<script src="assets/vendors/jquery/jquery-3.6.0.min.js"></script>
    <script src="assets/vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendors/jarallax/jarallax.min.js"></script>
    <script src="assets/vendors/jquery-ajaxchimp/jquery.ajaxchimp.min.js"></script>
    <script src="assets/vendors/jquery-appear/jquery.appear.min.js"></script>
    <script src="assets/vendors/jquery-circle-progress/jquery.circle-progress.min.js"></script>
    <script src="assets/vendors/jquery-magnific-popup/jquery.magnific-popup.min.js"></script>
    <script src="assets/vendors/jquery-validate/jquery.validate.min.js"></script>
    <script src="assets/vendors/nouislider/nouislider.min.js"></script>
    <script src="assets/vendors/odometer/odometer.min.js"></script>
    <script src="assets/vendors/swiper/swiper.min.js"></script>
    <script src="assets/vendors/tiny-slider/tiny-slider.min.js"></script>
    <script src="assets/vendors/wnumb/wNumb.min.js"></script>
    <script src="assets/vendors/wow/wow.js"></script>
    <script src="assets/vendors/isotope/isotope.js"></script>
    <script src="assets/vendors/countdown/countdown.min.js"></script>
    <script src="assets/vendors/owl-carousel/owl.carousel.min.js"></script>
    <script src="assets/vendors/bxslider/jquery.bxslider.min.js"></script>
    <script src="assets/vendors/bootstrap-select/js/bootstrap-select.min.js"></script>
    <script src="assets/vendors/vegas/vegas.min.js"></script>
    <script src="assets/vendors/jquery-ui/jquery-ui.js"></script>
    <script src="assets/vendors/timepicker/timePicker.js"></script>
    <script src="assets/vendors/circleType/jquery.circleType.js"></script>
    <script src="assets/vendors/circleType/jquery.lettering.min.js"></script>




    <!-- template js -->
    <script src="assets/js/agrion.js"></script>
<script type="text/javascript">
$(document).ready(function () {
 
window.setTimeout(function() {
    $(".alert").fadeTo(1000, 0).slideUp(1000, function(){
        $(this).remove(); 
    });
}, 5000);
 
});
</script>
</body>
</html>